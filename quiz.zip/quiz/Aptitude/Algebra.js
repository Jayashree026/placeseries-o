let questions = [
    {
    numb: 1,
    question: "The unique solution for equation pm+qn= 1 and pm-qn = 1 will be:",
    answer: "p=1 and q=1",
    options: [
      "p=1 and q=1",
      "p=1 and q=2",
      "p=0 and q=1",
      "None of the above."
    ]
  },
    {
    numb: 2,
    question: "Calculate the value of r from the equation ab - 3a + 5b + r?",
    answer: "-15",
    options: [
      "-34",
      "-15",
      "5",
      "0"
    ]
  },
    {
    numb: 3,
    question: "Adam is twice good in working as Smith. If by working together on the same task, they can finish the same in 14 days. If Adam is not well than Smith does the work alone. How much time would he require to finish the task?",
    answer: "42",
    options: [
      "41",
      "43",
      "42",
      "50"
    ]
  },
    {
    numb: 4,
    question: "30 students can write a thesis in 18 days when they study for 7 hours. How many days will 21 students who study for 8 hours take to finish that thesis assignment?",
    answer: "22.5",
    options: [
      "22",
      "21",
      "22.5"
    ]
  },
    {
    numb: 5,
    question: "A reduction is a 20% rate of Maize allows the consumer to acquire an additional 8 kg. for Rs 160. What is the reduced price per kg?",
    answer: "eXtensible Markup Language",
    options: [
     "4",
     "18",
     "20",
     "6"
    ]
  },
];
