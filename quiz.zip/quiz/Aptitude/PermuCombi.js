// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "Five people are sitting on a round table for meeting. These are P, Q, R, S, and T. In how many ways these people can be seated?",
    answer: "24",
    options: [
      "17",
      "24",
      "4",
      "9"
    ]
  },
    {
    numb: 2,
    question: "Find out the number of arrangements that can be made for the word RAINBOW if all the the vowels are placed on the even places?",
    answer: "144",
    options: [
      "144",
     "750",
     "55",
     "36"
    ]
  },
    {
    numb: 3,
    question: "There are 21 stations between Chennai and Darjeeling. Find out that what is the number of second class tickets have to be produced, so that a traveler can travel from any point of station to the any of the station?",
    answer: "506",
    options: [
      "950",
      "412",
      "506",
      "180"
    ]
  },
    {
    numb: 4,
    question: "Harry invited 20 people at a party. Determine the ways in which these people can be seated on a round table such that two specific people sit on either side of him.",
    answer: "18!*2",
    options: [
      "20!",
     "16!*4",
     "18!*2",
     "17!"
    ]
  },
    {
    numb: 5,
    question: "Out of numbers (1, 2,3,5,7 & 9) how many four digit even numbers can be formed?",
    answer: "60",
    options: [
      "60",
      "180",
      "20",
      "112"
    ]
  },
];
