// creating an array and passing the number, questions, options, and answers
let questions = [
    {
    numb: 1,
    question: "If log 5 = 0.698, find the number of digits in 5^25",
    answer: "90",
    options: [
      "90",
      "3",
      "18",
      "4"
    ]
  },
    {
    numb: 2,
    question: "Solve : px = qy",
    answer: "y/x",
    options: [
      "y/x",
      "x",
      "x/y",
      "None of the above."
    ]
  },
    {
    numb: 3,
    question: "Solve: log √9 /log 9",
    answer: "1/2",
    options: [
      "1",
      "1/2",
      "1/3",
      "2"
    ]
  },
    {
    numb: 4,
    question: "If log10 2 = 0.3010, the value of log10 80 is:",
    answer: "1.9030",
    options: [
      "2.7000",
      "1.9030",
      "2.4050",
      "2.3000"
    ]
  },
    {
    numb: 5,
    question: "If log 27 = 1.431, then the value of log 9 is:",
    answer: "0.594",
    options: [
      "1.604",
      "0.594",
      "2.001",
      "None of the above"
    ]
  },
];
