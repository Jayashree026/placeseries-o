// creating an array and passing the number, questions, options, and answers
let questions = [
  {
    numb: 1,
    question: "Which word does NOT belong with the others?",
    answer: "Mayonnaise",
    options: [
      "Parsley",
      "Mayonnaise",
      "Basil",
      "Dill"
    ]
  },
  {
    numb: 2,
    question: "Which word does NOT belong with the others?",
    answer: "Rye",
    options: [
      "Rye",
      "Sourdough",
      "Pumpernickel",
      "Loaf"
    ]
  },
  {
    numb: 3,
    question: "Marathon is to race as hibernation is to?",
    answer: "Sleep",
    options: [
      "Winter",
      "Bear",
      "Sleep",
      "Dream"
    ]
  },
  {
    numb: 4,
    question: "Odometer is to mileage as compass is to",
    answer: "Direction",
    options: [
      "Direction",
      "Needle",
      "Hiking",
      "Speed"
    ]
  },
  {
    numb: 5,
    question: "SCD, TEF, UGH, ____, WKL",
    answer: "VIJ",
    options: [
      "CMN",
      "VIJ",
      "UJI",
      "IJT"
    ]
  },
  {
    numb: 6,
    question: "B2CD, _____, BCD4, B5CD, BC6D",
    answer: "BC3D",
    options: [
      "BC3D",
      "B2C2D",
      "BCD7",
      "B2C3D"
    ]
  },
  

  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },
];
