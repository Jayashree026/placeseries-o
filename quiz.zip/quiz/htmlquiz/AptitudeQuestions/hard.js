let questions=[{
numb: 1,
question: "Total number of factors of 72 is",
answer: "12",
options: [
  "15",
  "12",
  "13",
  "18"
]
},
{
numb: 2,
question: "When a number is divided by 9, then the remainder is 2. What will be the remainder when the square of that number is divided by 9?",
answer: "4",
options: [
  "3",
  "6",
  "8",
  "4"
]
},
{
numb: 3,
question: "When a number is divided by 32, the quotient is 27 and remainder is 6. What will be the remainder when the same number is divided by 17?",
answer: "3",
options: [
  "3",
  "4",
  "7",
  "11"
]
},
{
numb: 4,
question: "If Product of two numbers is 1750 and LCM is 350 then what will be the HCF of those two numbers?",
answer: "5",
options: [
  "5",
  "4",
  "8",
  "10"
]
},
{
numb: 5,
question: "How many of the following numbers are divisible by 3 but not by 9. 4320, 2343, 3474, 4131, 5286, 5340, 6336, 7347, 8115, 9276?",
answer: "6",
options: [
  "5",
  "6",
  "4",
  "3"
]
},
{
numb: 6,
question: "The difference between the squares of two consecutive odd integers is always divisible by?",
answer: "8",
options: [
  "1",
  "4",
  "8",
  "3"
]
},
{
numb: 7,
question: "If p and q are the two digits of the number 653pq such that this number is divisible by 80, then p+q is equal to?",
answer: "2",
options: [
  "3",
  "2",
  "5",
  "7"
]
},
];
