let questions = [{
  numb: 1,
  question: "Which keyword is used to prevent any changes in the variable within a C program?",
  answer: "const",
  options: [
    "immutable",
    "mutable",
    "const",
    "volatile"
  ]
},
{
  numb: 2,
  question: "What will be the value of the following Python expression : 4 + 3 % 5",
  answer: "7",
  options: [
    "7",
    "2",
    "4",
    "1"
  ]
},
{
  numb: 3,
  question: " Which keyword is used for function in Python language?",
  answer: "def",
  options: [
    "Function",
    "def",
    "Fun",
    "Define"
  ]
},
];
