let questions = [{
  numb: 1,
  question: "What is the order of precedence in python?",
  answer: "Parentheses, Exponential, Multiplication, Division, Addition, Subtraction",
  options: [
    "Exponential, Parentheses, Multiplication, Division, Addition, Subtraction",
    "Exponential, Parentheses, Division, Multiplication, Addition, Subtraction",
    "Parentheses, Exponential, Multiplication, Division, Subtraction, Addition",
    "Parentheses, Exponential, Multiplication, Division, Addition, Subtraction"
  ]
},
{
  numb: 2,
  question: "What will be the output of the following Python code : if x=1 when x<<2?",
  answer: "4",
  options: [
    "4",
    "2",
    "1",
    "8"
  ]
},
{
  numb: 3,
  question: "What does pip stand for python?",
  answer: "Preferred Installer Program",
  options: [
    "Pip Installs Python",
    "Pip Installs Packages",
    "Preferred Installer Program",
    "All of the mentioned"
  ]
},
];
